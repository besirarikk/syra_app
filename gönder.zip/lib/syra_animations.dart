// LEGACY COMPAT WRAPPER – use lib/theme/syra_animations.dart
export 'theme/syra_animations.dart';
