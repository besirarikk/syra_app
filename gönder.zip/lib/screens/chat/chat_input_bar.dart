// lib/screens/chat/chat_input_bar.dart

import 'dart:io';
import 'dart:math';
import 'dart:ui';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart'; // ← HAPTIC FEEDBACK
import '../../theme/syra_theme.dart';
import '../../theme/syra_glass.dart';

/// ═══════════════════════════════════════════════════════════════
/// CLAUDE iOS MOBILE STYLE WITH HAPTICS
/// ═══════════════════════════════════════════════════════════════
/// Premium input bar with:
/// - "SYRA ile Sohbet" title
/// - [+] [timer] [TextField] [mic] [voice/send]
/// - Heavy glassmorphism
/// - Haptic feedback on all interactions
/// ═══════════════════════════════════════════════════════════════

class ChatInputBar extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final bool isSending;
  final bool isLoading;
  final bool isListening;
  final Map<String, dynamic>? replyingTo;
  final File? pendingImage;
  final String? pendingImageUrl;
  final VoidCallback onAttachmentTap;
  final VoidCallback onVoiceInputTap;
  final VoidCallback onSendMessage;
  final VoidCallback onCancelReply;
  final VoidCallback onClearImage;
  final VoidCallback onTextChanged;

  const ChatInputBar({
    super.key,
    required this.controller,
    required this.focusNode,
    required this.isSending,
    required this.isLoading,
    required this.isListening,
    this.replyingTo,
    this.pendingImage,
    this.pendingImageUrl,
    required this.onAttachmentTap,
    required this.onVoiceInputTap,
    required this.onSendMessage,
    required this.onCancelReply,
    required this.onClearImage,
    required this.onTextChanged,
  });

  @override
  Widget build(BuildContext context) {
    final bool hasText = controller.text.trim().isNotEmpty;
    final bool isUploadingImage = pendingImage != null && pendingImageUrl == null;
    final bool hasPendingImage = pendingImage != null && pendingImageUrl != null;
    final bool canSend = (hasText || hasPendingImage) &&
        !isSending &&
        !isLoading &&
        !isUploadingImage;

    return SafeArea(
      top: false,
      child: Padding(
        padding: EdgeInsets.fromLTRB(
          SyraSpacing.md,
          SyraSpacing.sm,
          SyraSpacing.md,
          SyraSpacing.md,
        ),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            if (replyingTo != null) ...[
              _buildReplyPreview(),
              SizedBox(height: SyraSpacing.sm),
            ],
            if (pendingImage != null) ...[
              _buildImagePreview(),
              SizedBox(height: SyraSpacing.sm),
            ],
            _buildClaudeStyleCard(context, canSend, hasText),
          ],
        ),
      ),
    );
  }

  Widget _buildClaudeStyleCard(BuildContext context, bool canSend, bool hasText) {
    return ClipRRect(
      borderRadius: BorderRadius.circular(28),
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 20, sigmaY: 20),
        child: Container(
          decoration: BoxDecoration(
            gradient: LinearGradient(
              begin: Alignment.topLeft,
              end: Alignment.bottomRight,
              colors: [
                Color(0xFF2A2A2A).withOpacity(0.7),
                Color(0xFF1F1F1F).withOpacity(0.8),
              ],
            ),
            borderRadius: BorderRadius.circular(28),
            border: Border.all(
              color: Colors.white.withOpacity(0.1),
              width: 1.5,
            ),
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.5),
                blurRadius: 30,
                offset: Offset(0, 10),
              ),
            ],
          ),
          padding: EdgeInsets.symmetric(horizontal: 20, vertical: 16),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            mainAxisSize: MainAxisSize.min,
            children: [
              if (!hasText && !isListening)
                Padding(
                  padding: EdgeInsets.only(bottom: 16, left: 4),
                  child: Text(
                    'SYRA ile Sohbet',
                    style: SyraTextStyles.headingMedium.copyWith(
                      color: Colors.white.withOpacity(0.9),
                      fontSize: 22,
                      fontWeight: FontWeight.w600,
                      letterSpacing: -0.5,
                    ),
                  ),
                ),
              Row(
                crossAxisAlignment: CrossAxisAlignment.center,
                children: [
                  _buildCircularIconButton(
                    icon: Icons.add_rounded,
                    onTap: () {
                      HapticFeedback.lightImpact(); // ← HAPTIC
                      onAttachmentTap();
                    },
                    size: 48,
                  ),
                  SizedBox(width: 8),
                  _buildCircularIconButton(
                    icon: Icons.access_time_rounded,
                    onTap: () {
                      HapticFeedback.lightImpact(); // ← HAPTIC
                    },
                    size: 48,
                  ),
                  SizedBox(width: 16),
                  Expanded(
                    child: TextField(
                      controller: controller,
                      focusNode: focusNode,
                      enabled: !isSending,
                      maxLines: 4,
                      minLines: 1,
                      onChanged: (_) => onTextChanged(),
                      style: SyraTextStyles.bodyLarge.copyWith(
                        color: Colors.white,
                        fontSize: 17,
                        height: 1.4,
                      ),
                      decoration: InputDecoration(
                        isDense: true,
                        contentPadding: EdgeInsets.zero,
                        border: InputBorder.none,
                        hintText: hasText ? null : "",
                        hintStyle: SyraTextStyles.bodyLarge.copyWith(
                          color: Colors.white.withOpacity(0.4),
                          fontSize: 17,
                        ),
                      ),
                      onSubmitted: (_) {
                        if (canSend) {
                          HapticFeedback.mediumImpact(); // ← HAPTIC
                          onSendMessage();
                        }
                      },
                    ),
                  ),
                  SizedBox(width: 16),
                  if (!canSend && !isListening)
                    _buildSimpleIconButton(
                      icon: Icons.mic_none_rounded,
                      onTap: () {
                        HapticFeedback.lightImpact(); // ← HAPTIC
                        onVoiceInputTap();
                      },
                    ),
                  if (!canSend && !isListening) SizedBox(width: 8),
                  _buildActionButton(canSend),
                ],
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildCircularIconButton({
    required IconData icon,
    required VoidCallback onTap,
    required double size,
  }) {
    return _TapScale(
      onTap: onTap,
      child: Container(
        width: size,
        height: size,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          shape: BoxShape.circle,
          border: Border.all(
            color: Colors.white.withOpacity(0.1),
            width: 1,
          ),
        ),
        child: Icon(
          icon,
          size: 24,
          color: Colors.white.withOpacity(0.8),
        ),
      ),
    );
  }

  Widget _buildSimpleIconButton({
    required IconData icon,
    required VoidCallback onTap,
  }) {
    return _TapScale(
      onTap: onTap,
      child: Icon(
        icon,
        size: 26,
        color: Colors.white.withOpacity(0.7),
      ),
    );
  }

  Widget _buildActionButton(bool canSend) {
    if (canSend) {
      return _TapScale(
        onTap: () {
          HapticFeedback.mediumImpact(); // ← HAPTIC (stronger)
          onSendMessage();
        },
        child: Container(
          width: 48,
          height: 48,
          decoration: BoxDecoration(
            gradient: SyraColors.accentGradient,
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: SyraColors.accent.withOpacity(0.4),
                blurRadius: 16,
                offset: Offset(0, 6),
              ),
            ],
          ),
          child: Center(
            child: isSending
                ? SizedBox(
                    width: 20,
                    height: 20,
                    child: CircularProgressIndicator(
                      strokeWidth: 2.5,
                      valueColor: AlwaysStoppedAnimation(Colors.white),
                    ),
                  )
                : Icon(
                    Icons.arrow_upward_rounded,
                    size: 24,
                    color: Colors.white,
                  ),
          ),
        ),
      );
    } else {
      return _TapScale(
        onTap: () {
          HapticFeedback.lightImpact(); // ← HAPTIC
          onVoiceInputTap();
        },
        child: Container(
          width: 56,
          height: 56,
          decoration: BoxDecoration(
            color: isListening
                ? Colors.white
                : Colors.white.withOpacity(0.9),
            shape: BoxShape.circle,
            boxShadow: [
              BoxShadow(
                color: Colors.black.withOpacity(0.3),
                blurRadius: 20,
                offset: Offset(0, 8),
              ),
            ],
          ),
          child: Center(
            child: isListening
                ? _VoiceWaveAnimation()
                : Icon(
                    Icons.graphic_eq_rounded,
                    size: 28,
                    color: Color(0xFF1F1F1F),
                  ),
          ),
        ),
      );
    }
  }

  Widget _buildReplyPreview() {
    return ClipRRect(
      borderRadius: BorderRadius.circular(SyraRadius.md),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: SyraGlass.blurSubtle,
          sigmaY: SyraGlass.blurSubtle,
        ),
        child: Container(
          padding: EdgeInsets.all(SyraSpacing.sm),
          decoration: BoxDecoration(
            color: SyraColors.surface.withOpacity(0.3),
            borderRadius: BorderRadius.circular(SyraRadius.md),
            border: Border.all(
              color: SyraColors.accent.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              Container(
                width: 3,
                height: 40,
                decoration: BoxDecoration(
                  color: SyraColors.accent,
                  borderRadius: BorderRadius.circular(2),
                ),
              ),
              SizedBox(width: SyraSpacing.sm),
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Yanıtlanıyor',
                      style: SyraTextStyles.caption.copyWith(
                        color: SyraColors.accent,
                        fontWeight: FontWeight.w600,
                      ),
                    ),
                    SizedBox(height: 4),
                    Text(
                      replyingTo?['text'] ?? '',
                      maxLines: 2,
                      overflow: TextOverflow.ellipsis,
                      style: SyraTextStyles.bodySmall.copyWith(
                        color: SyraColors.textSecondary,
                      ),
                    ),
                  ],
                ),
              ),
              _TapScale(
                onTap: () {
                  HapticFeedback.lightImpact(); // ← HAPTIC
                  onCancelReply();
                },
                child: Icon(
                  Icons.close_rounded,
                  size: 20,
                  color: SyraColors.iconMuted,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  Widget _buildImagePreview() {
    final bool isUploading = pendingImageUrl == null;

    return ClipRRect(
      borderRadius: BorderRadius.circular(SyraRadius.md),
      child: BackdropFilter(
        filter: ImageFilter.blur(
          sigmaX: SyraGlass.blurSubtle,
          sigmaY: SyraGlass.blurSubtle,
        ),
        child: Container(
          padding: EdgeInsets.all(SyraSpacing.sm),
          decoration: BoxDecoration(
            color: SyraColors.surface.withOpacity(0.3),
            borderRadius: BorderRadius.circular(SyraRadius.md),
            border: Border.all(
              color: SyraColors.border.withOpacity(0.3),
              width: 1,
            ),
          ),
          child: Row(
            children: [
              ClipRRect(
                borderRadius: BorderRadius.circular(SyraRadius.sm),
                child: SizedBox(
                  width: 60,
                  height: 60,
                  child: Stack(
                    fit: StackFit.expand,
                    children: [
                      Image.file(pendingImage!, fit: BoxFit.cover),
                      if (isUploading)
                        Container(
                          color: Colors.black.withOpacity(0.5),
                          child: Center(
                            child: SizedBox(
                              width: 24,
                              height: 24,
                              child: CircularProgressIndicator(
                                strokeWidth: 2,
                                valueColor:
                                    AlwaysStoppedAnimation(SyraColors.accent),
                              ),
                            ),
                          ),
                        ),
                    ],
                  ),
                ),
              ),
              SizedBox(width: SyraSpacing.sm),
              Expanded(
                child: Text(
                  isUploading ? 'Yükleniyor...' : 'Resim hazır',
                  style: SyraTextStyles.bodyMedium.copyWith(
                    color: SyraColors.textSecondary,
                  ),
                ),
              ),
              if (!isUploading)
                _TapScale(
                  onTap: () {
                    HapticFeedback.lightImpact(); // ← HAPTIC
                    onClearImage();
                  },
                  child: Icon(
                    Icons.close_rounded,
                    size: 20,
                    color: SyraColors.iconMuted,
                  ),
                ),
            ],
          ),
        ),
      ),
    );
  }
}

// ═══════════════════════════════════════════════════════════════
// VOICE WAVE ANIMATION
// ═══════════════════════════════════════════════════════════════

class _VoiceWaveAnimation extends StatefulWidget {
  const _VoiceWaveAnimation();

  @override
  State<_VoiceWaveAnimation> createState() => _VoiceWaveAnimationState();
}

class _VoiceWaveAnimationState extends State<_VoiceWaveAnimation>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 1200),
    )..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, child) {
        return CustomPaint(
          size: Size(28, 28),
          painter: _VoiceWavePainter(_controller.value),
        );
      },
    );
  }
}

class _VoiceWavePainter extends CustomPainter {
  final double progress;

  _VoiceWavePainter(this.progress);

  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Color(0xFF1F1F1F)
      ..strokeWidth = 2.5
      ..strokeCap = StrokeCap.round;

    final centerY = size.height / 2;
    final barWidth = 3.0;
    final spacing = 4.0;
    final bars = 5;

    for (int i = 0; i < bars; i++) {
      final offset = (progress + i / bars) % 1.0;
      final height = sin(offset * pi * 2) * (size.height / 2 - 4) + 8;
      final x = (size.width - (bars - 1) * (barWidth + spacing)) / 2 +
          i * (barWidth + spacing);

      canvas.drawLine(
        Offset(x, centerY - height / 2),
        Offset(x, centerY + height / 2),
        paint,
      );
    }
  }

  @override
  bool shouldRepaint(_VoiceWavePainter oldDelegate) => true;
}

// ═══════════════════════════════════════════════════════════════
// TAP SCALE ANIMATION WITH HAPTIC
// ═══════════════════════════════════════════════════════════════

class _TapScale extends StatefulWidget {
  final Widget child;
  final VoidCallback? onTap;

  const _TapScale({
    required this.child,
    this.onTap,
  });

  @override
  State<_TapScale> createState() => _TapScaleState();
}

class _TapScaleState extends State<_TapScale>
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      vsync: this,
      duration: Duration(milliseconds: 100),
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.94).animate(
      CurvedAnimation(
        parent: _controller,
        curve: Curves.easeOut,
      ),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap != null
          ? (_) {
              HapticFeedback.selectionClick(); // ← HAPTIC on press
              _controller.forward();
            }
          : null,
      onTapUp: widget.onTap != null ? (_) => _controller.reverse() : null,
      onTapCancel: widget.onTap != null ? () => _controller.reverse() : null,
      onTap: widget.onTap,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: widget.child,
      ),
    );
  }
}
