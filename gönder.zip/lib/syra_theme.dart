// LEGACY COMPAT WRAPPER – use lib/theme/syra_theme.dart
export 'theme/syra_theme.dart';
