import 'dart:ui';
import 'dart:math';
import 'package:flutter/material.dart';
import '../theme/syra_theme.dart';

/// Premium glassmorphism message input bar
/// 
/// Features:
/// - Pill-shaped container with blur effect
/// - Smooth state transitions (idle/focused/active)
/// - Support for leading, trailing and send buttons
/// - Handles keyboard behavior
/// - Animated border and shadow on focus
class SyraMessageInputBar extends StatelessWidget {
  final TextEditingController controller;
  final FocusNode focusNode;
  final String hintText;
  final bool enabled;
  final VoidCallback? onSend;
  final VoidCallback? onAttachment;
  final VoidCallback? onVoiceInput;
  final Widget? replyPreview;
  final Widget? imagePreview;
  final bool isLoading;
  final bool isSending;
  final int maxLines;
  final int minLines;
  final EdgeInsets? contentPadding;

  const SyraMessageInputBar({
    super.key,
    required this.controller,
    required this.focusNode,
    this.hintText = "Message",
    this.enabled = true,
    this.onSend,
    this.onAttachment,
    this.onVoiceInput,
    this.replyPreview,
    this.imagePreview,
    this.isLoading = false,
    this.isSending = false,
    this.maxLines = 5,
    this.minLines = 1,
    this.contentPadding,
  });

  @override
  Widget build(BuildContext context) {
    final hasText = controller.text.trim().isNotEmpty;
    final isFocused = focusNode.hasFocus;
    final isActive = isFocused || hasText;
    final canSend = hasText && !isSending && !isLoading;

    return Container(
      padding: contentPadding ?? EdgeInsets.fromLTRB(
        16,
        8,
        16,
        max(8.0, MediaQuery.of(context).padding.bottom - 20),
      ),
      decoration: BoxDecoration(
        color: SyraColors.background,
        border: Border(
          top: BorderSide(
            color: SyraColors.divider,
            width: 0.5,
          ),
        ),
      ),
      child: Column(
        mainAxisSize: MainAxisSize.min,
        children: [
          // Reply preview
          if (replyPreview != null) replyPreview!,
          
          // Image preview
          if (imagePreview != null) imagePreview!,
          
          // Main input container with glassmorphism
          ClipRRect(
            borderRadius: BorderRadius.circular(24),
            child: BackdropFilter(
              filter: ImageFilter.blur(sigmaX: 8, sigmaY: 8),
              child: AnimatedContainer(
                duration: const Duration(milliseconds: 180),
                curve: Curves.easeInOut,
                decoration: BoxDecoration(
                  color: isActive 
                      ? SyraColors.surfaceLight.withValues(alpha: 0.8)
                      : SyraColors.surface.withValues(alpha: 0.6),
                  borderRadius: BorderRadius.circular(24),
                  border: Border.all(
                    color: isActive
                        ? SyraColors.accent.withValues(alpha: 0.8)
                        : SyraColors.border,
                    width: isActive ? 1.2 : 0.5,
                  ),
                  boxShadow: isActive
                      ? [
                          BoxShadow(
                            color: Colors.black.withValues(alpha: 0.45),
                            blurRadius: 22,
                            offset: const Offset(0, 6),
                          ),
                        ]
                      : [],
                ),
                child: Row(
                  crossAxisAlignment: CrossAxisAlignment.end,
                  children: [
                    // Attachment button
                    if (onAttachment != null)
                      _InputButton(
                        onTap: onAttachment,
                        child: const Icon(
                          Icons.add_rounded,
                          color: SyraColors.textMuted,
                          size: 24,
                        ),
                      ),

                    // Text input field
                    Expanded(
                      child: TextField(
                        controller: controller,
                        focusNode: focusNode,
                        enabled: enabled && !isSending,
                        maxLines: maxLines,
                        minLines: minLines,
                        style: const TextStyle(
                          color: SyraColors.textPrimary,
                          fontSize: 15,
                          height: 1.4,
                        ),
                        decoration: InputDecoration(
                          isDense: true,
                          contentPadding: const EdgeInsets.symmetric(
                            horizontal: 4,
                            vertical: 12,
                          ),
                          border: InputBorder.none,
                          hintText: hintText,
                          hintStyle: const TextStyle(
                            color: SyraColors.textHint,
                            fontSize: 15,
                          ),
                        ),
                        onSubmitted: (_) => canSend ? onSend?.call() : null,
                      ),
                    ),

                    // Voice input button
                    if (onVoiceInput != null)
                      _InputButton(
                        onTap: onVoiceInput,
                        child: const Icon(
                          Icons.mic_none_rounded,
                          color: SyraColors.textMuted,
                          size: 24,
                        ),
                      ),

                    // Send button with animation
                    if (onSend != null)
                      _InputButton(
                        onTap: canSend ? onSend : null,
                        child: AnimatedContainer(
                          duration: const Duration(milliseconds: 200),
                          curve: Curves.easeInOut,
                          width: 40,
                          height: 40,
                          decoration: BoxDecoration(
                            color: canSend
                                ? SyraColors.textPrimary
                                : SyraColors.textMuted.withValues(alpha: 0.3),
                            shape: BoxShape.circle,
                          ),
                          child: isLoading
                              ? const Padding(
                                  padding: EdgeInsets.all(10),
                                  child: CircularProgressIndicator(
                                    strokeWidth: 2,
                                    valueColor: AlwaysStoppedAnimation<Color>(
                                      SyraColors.background,
                                    ),
                                  ),
                                )
                              : Icon(
                                  Icons.arrow_upward_rounded,
                                  color: canSend
                                      ? SyraColors.background
                                      : SyraColors.textMuted,
                                  size: 20,
                                ),
                        ),
                      ),
                  ],
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }
}

/// Helper widget for input bar buttons
class _InputButton extends StatefulWidget {
  final VoidCallback? onTap;
  final Widget child;

  const _InputButton({
    this.onTap,
    required this.child,
  });

  @override
  State<_InputButton> createState() => _InputButtonState();
}

class _InputButtonState extends State<_InputButton> 
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.88).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _handleTapUp(TapUpDetails details) {
    _controller.reverse();
  }

  void _handleTapCancel() {
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap != null ? _handleTapDown : null,
      onTapUp: widget.onTap != null ? _handleTapUp : null,
      onTapCancel: widget.onTap != null ? _handleTapCancel : null,
      onTap: widget.onTap,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          width: 44,
          height: 44,
          margin: const EdgeInsets.only(left: 4, right: 2, bottom: 4),
          alignment: Alignment.center,
          child: widget.child,
        ),
      ),
    );
  }
}
