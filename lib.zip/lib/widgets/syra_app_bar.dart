import 'dart:ui';
import 'package:flutter/material.dart';
import '../theme/syra_theme.dart';
import '../theme/syra_tokens.dart';

/// Premium glassmorphism app bar for SYRA
/// 
/// Features:
/// - Semi-transparent background with blur effect
/// - Subtle bottom border for separation
/// - Flexible title widget support
/// - Leading and trailing action buttons
class SyraAppBar extends StatelessWidget {
  final Widget? title;
  final Widget? leading;
  final List<Widget>? actions;
  final double height;
  final Color? backgroundColor;
  final Color? borderColor;

  const SyraAppBar({
    super.key,
    this.title,
    this.leading,
    this.actions,
    this.height = 56,
    this.backgroundColor,
    this.borderColor,
  });

  @override
  Widget build(BuildContext context) {
    return ClipRect(
      child: BackdropFilter(
        filter: ImageFilter.blur(sigmaX: 10, sigmaY: 10),
        child: Container(
          height: height,
          padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 10),
          decoration: BoxDecoration(
            color: backgroundColor ?? 
                   SyraColors.background.withValues(alpha: 0.85),
            border: Border(
              bottom: BorderSide(
                color: borderColor ?? SyraColors.divider,
                width: 0.5,
              ),
            ),
          ),
          child: Row(
            children: [
              // Leading widget
              if (leading != null) leading!,
              
              // Title - centered and expanded
              Expanded(
                child: Center(
                  child: title ?? const SizedBox.shrink(),
                ),
              ),
              
              // Trailing actions
              if (actions != null && actions!.isNotEmpty)
                ...actions!.map((action) => Padding(
                  padding: const EdgeInsets.only(left: 4),
                  child: action,
                )),
            ],
          ),
        ),
      ),
    );
  }
}

/// Helper widget for app bar buttons with scale animation
class SyraAppBarButton extends StatefulWidget {
  final VoidCallback? onTap;
  final Widget child;
  final double size;
  final Color? backgroundColor;

  const SyraAppBarButton({
    super.key,
    this.onTap,
    required this.child,
    this.size = 40,
    this.backgroundColor,
  });

  @override
  State<SyraAppBarButton> createState() => _SyraAppBarButtonState();
}

class _SyraAppBarButtonState extends State<SyraAppBarButton> 
    with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _scaleAnimation;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(milliseconds: 100),
      vsync: this,
    );
    _scaleAnimation = Tween<double>(begin: 1.0, end: 0.92).animate(
      CurvedAnimation(parent: _controller, curve: Curves.easeInOut),
    );
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  void _handleTapDown(TapDownDetails details) {
    _controller.forward();
  }

  void _handleTapUp(TapUpDetails details) {
    _controller.reverse();
  }

  void _handleTapCancel() {
    _controller.reverse();
  }

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTapDown: widget.onTap != null ? _handleTapDown : null,
      onTapUp: widget.onTap != null ? _handleTapUp : null,
      onTapCancel: widget.onTap != null ? _handleTapCancel : null,
      onTap: widget.onTap,
      child: ScaleTransition(
        scale: _scaleAnimation,
        child: Container(
          width: widget.size,
          height: widget.size,
          decoration: BoxDecoration(
            color: widget.backgroundColor ?? Colors.transparent,
            borderRadius: BorderRadius.circular(8),
          ),
          child: widget.child,
        ),
      ),
    );
  }
}
